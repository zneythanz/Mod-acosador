# Stalker Horror (Fabric 1.20.1)

Mod de terror ligero. Una criatura alta y delgada te observa desde la oscuridad:

- **La miras → se congela.** Si la miras demasiado tiempo desde lejos, desaparece y vuelve **más cerca** (5 fases).
- **Apartas la vista → se acerca.** Y corre más cuanto más cerca está.
- **Llega hasta ti → susto**: aparece pegada a tu cara, grita, te hace 2.5 corazones de daño y se va.
- Si **la miras fijamente estando cerca**, pierde la paciencia y te ataca.
- Si le pegas, huye asustada.

Sonido 3D: latido (más rápido al acercarse), respiración que viene desde su posición, susurros junto a tu oído, zumbido grave al aparecer y grito. A partir de la fase 2, pulsos de oscuridad cuando está cerca.

## Compilar

Necesitas **JDK 17 o superior** y conexión a internet (la primera vez descarga Minecraft y las herramientas).

```
./gradlew build          (Linux / Mac)
gradlew.bat build        (Windows)
```

El mod queda en `build/libs/stalker-horror-1.0.0.jar` (**no** uses el que dice `-sources`).

## Instalar

1. Instala Fabric Loader para 1.20.1.
2. Pon en la carpeta `mods`: `stalker-horror-1.0.0.jar` y **Fabric API** (0.92.2+1.20.1 o más nuevo para 1.20.1).

## Probarlo rápido

Crea un mundo con trucos y usa:

| Comando | Qué hace |
|---|---|
| `/stalker spawn` | Lo invoca ahora mismo |
| `/stalker stage 0-5` | Fija la fase (más alta = aparece más cerca) |
| `/stalker clear` | Lo elimina |
| `/stalker natural false` | Apaga la aparición natural |

Sin comandos aparece solo de noche o en lugares oscuros (cuevas), después de ~1 minuto de calma.

## Ajustes

Todo está en `src/main/java/com/stalkerhorror/StalkerConfig.java` (velocidad, distancias, tiempo de mirada, daño, oscuridad, etc.). Cambia el número y vuelve a compilar.

## Rendimiento (pensado para Quest)

- Modelo de solo 6 cubos y textura de 64×64; los ojos brillantes son una sola capa extra.
- Sin librerías de animación: todo se calcula en código.
- Máximo **1 Acosador por jugador**; la ruta se recalcula solo cada medio segundo.
- No hay overlays de pantalla ni sacudidas de cámara (dan mareo y a veces no se ven en VR). El susto es con la criatura en tu cara + sonido + oscuridad.

## Personalizar

- Texturas: `src/main/resources/assets/stalkerhorror/textures/entity/` (`stalker.png` y `stalker_eyes.png`, 64×64).
- Sonidos: `src/main/resources/assets/stalkerhorror/sounds/*.ogg` (deben ser **mono**).
