# Stalker Horror 1.1 (Fabric 1.20.1)

Una sola criatura, **El Acosador**: alta, delgada, cabeza larga, brazos casi hasta los tobillos y ojos que brillan.
Te busca de cuatro formas distintas (el mod elige una al azar):

| Modo | Qué hace |
|---|---|
| **Ventana** | Aparece **afuera**, pegado al vidrio de tu casa y te observa. Si te acercas y no lo miras, **pega las manos al cristal y golpea**. Si lo miras fijo, **grita** pegado al vidrio. |
| **Puerta** | Espera detrás de una puerta de madera, **toca**, la **abre** ("Mira detrás de la puerta...") y, si estás cerca, **mete la mano y se lanza a agarrarte**. |
| **Detrás** | Aparece **de verdad a tu espalda** y te dice "Estoy detrás de ti...". Si volteas, grita en tu cara. Si no volteas, se acerca poco a poco y te ataca. |
| **Acechar** | Te sigue de lejos: **si lo miras se congela, si no lo miras se acerca**. Si lo miras mucho, desaparece y vuelve más cerca (5 fases). |

Además: **gritos lejanos** cuando giras la cabeza de golpe (de noche o en cuevas), latido del corazón que se acelera,
respiración que viene desde su posición, susurros junto al oído y frases en la barra de arriba.

Ventana y puerta solo aparecen cuando estás **dentro de un lugar techado** (casa, base, cueva con vidrio o puertas).

## Pensado para VR (QuestCraft)

- Una sola criatura por jugador, modelo de 6 cubos y una sola textura de 512×512.
- Sin sacudidas de cámara ni pantallazos (marean en VR). El susto es la criatura en tu cara + sonido + oscuridad.
- Las frases salen en la barra de arriba (action bar), que sí se ve en QuestCraft.

## Compilar

Con GitHub (como ya hiciste): sube este zip con el **mismo nombre** (`stalker-horror.zip`) al repositorio
y la pestaña **Actions** compila solo. El mod queda en el artifact `stalker-horror-mod`.

Con PC: `./gradlew build` → `build/libs/stalker-horror-1.1.0.jar` (no uses el `-sources`).

## Instalar

Pon `stalker-horror-1.1.0.jar` y **Fabric API 0.92.2+1.20.1** (o más nueva para 1.20.1) en la carpeta `mods`.

## Probarlo rápido (trucos activados)

| Comando | Qué hace |
|---|---|
| `/stalker spawn` | Lo invoca en un modo al azar |
| `/stalker spawn ventana` | Pegado al vidrio (necesitas estar dentro de una casa con ventanas) |
| `/stalker spawn puerta` | Detrás de una puerta de madera cerrada |
| `/stalker spawn detras` | A tu espalda |
| `/stalker spawn acechar` | Te sigue |
| `/stalker grito` | Prueba el grito lejano |
| `/stalker stage 0-5` | Fase (más alta = aparece más cerca al acechar) |
| `/stalker clear` | Lo elimina |
| `/stalker natural false` | Apaga la aparición natural |

Sin comandos aparece solo de noche o en lugares oscuros, después de ~1 minuto de calma.
Juega en **supervivencia** (en creativo no te toma en cuenta igual).

## Ajustes

Todo está en `src/main/java/com/stalkerhorror/StalkerConfig.java` (frecuencia, daño, tiempos, alcance de la mano,
probabilidad de gritos, etc.). Cambia el número y vuelve a compilar.

## Cambiar la cara o los sonidos

- Textura: `src/main/resources/assets/stalkerhorror/textures/entity/stalker.png` (512×512) y `stalker_eyes.png` (brillo de ojos).
- Sonidos: `src/main/resources/assets/stalkerhorror/sounds/*.ogg` (deben ser **mono**).
