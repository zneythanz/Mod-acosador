package com.stalkerhorror.client;

import com.stalkerhorror.StalkerHorror;
import com.stalkerhorror.entity.StalkerEntity;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.MobEntityRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;

@Environment(EnvType.CLIENT)
public class StalkerRenderer extends MobEntityRenderer<StalkerEntity, StalkerModel> {
    private static final Identifier TEXTURE =
            new Identifier(StalkerHorror.MOD_ID, "textures/entity/stalker.png");

    public StalkerRenderer(EntityRendererFactory.Context context) {
        super(context, new StalkerModel(context.getPart(StalkerModel.LAYER)), 0.45f);
        this.addFeature(new StalkerEyesFeature(this));
    }

    @Override
    public Identifier getTexture(StalkerEntity entity) {
        return TEXTURE;
    }

    @Override
    protected void scale(StalkerEntity entity, MatrixStack matrices, float amount) {
        // El modelo mide ~2.6 bloques; con 1.1 llega a ~2.9 de alto.
        matrices.scale(1.1f, 1.1f, 1.1f);
    }
}
