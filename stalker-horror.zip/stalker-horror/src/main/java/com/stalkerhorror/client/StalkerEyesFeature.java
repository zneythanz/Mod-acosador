package com.stalkerhorror.client;

import com.stalkerhorror.StalkerHorror;
import com.stalkerhorror.entity.StalkerEntity;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.entity.feature.EyesFeatureRenderer;
import net.minecraft.client.render.entity.feature.FeatureRendererContext;
import net.minecraft.util.Identifier;

/** Los destellos de los ojos brillan en la oscuridad (mismo truco que la arana). */
@Environment(EnvType.CLIENT)
public class StalkerEyesFeature extends EyesFeatureRenderer<StalkerEntity, StalkerModel> {
    private static final RenderLayer EYES =
            RenderLayer.getEyes(new Identifier(StalkerHorror.MOD_ID, "textures/entity/stalker_eyes.png"));

    public StalkerEyesFeature(FeatureRendererContext<StalkerEntity, StalkerModel> context) {
        super(context);
    }

    @Override
    public RenderLayer getEyesTexture() {
        return EYES;
    }
}
