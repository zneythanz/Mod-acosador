package com.stalkerhorror.client;

import com.stalkerhorror.StalkerHorror;
import com.stalkerhorror.entity.StalkerEntity;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.model.ModelData;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.model.ModelPartBuilder;
import net.minecraft.client.model.ModelPartData;
import net.minecraft.client.model.ModelTransform;
import net.minecraft.client.model.TexturedModelData;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.entity.model.EntityModel;
import net.minecraft.client.render.entity.model.EntityModelLayer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;

/**
 * Modelo del Acosador: muy alto y delgado, cabeza alargada y brazos casi hasta los tobillos.
 * Solo 6 cubos (muy barato de dibujar); las animaciones se calculan a mano, sin librerias extra.
 *
 * El modelo esta dibujado a escala x8 (los cubos son 8 veces mas grandes) y se reduce al
 * renderizar. Asi la textura tiene 8 texels por pixel de modelo y la cara puede tener detalle.
 * Los pivotes estan medidos desde los pies (y = 0 en el suelo, hacia arriba es negativo).
 *
 * Textura 512x512 (box UV):
 *   cabeza (0,0)  torso (0,160)  brazo der (230,0)  brazo izq (300,0)
 *   pierna der (370,0)  pierna izq (440,0)
 */
@Environment(EnvType.CLIENT)
public class StalkerModel extends EntityModel<StalkerEntity> {
    public static final EntityModelLayer LAYER =
            new EntityModelLayer(new Identifier(StalkerHorror.MOD_ID, "stalker"), "main");

    private static final float MODEL_SCALE = 8.0f;

    private final ModelPart root;
    private final ModelPart body;
    private final ModelPart head;
    private final ModelPart rightArm;
    private final ModelPart leftArm;
    private final ModelPart rightLeg;
    private final ModelPart leftLeg;

    public StalkerModel(ModelPart root) {
        this.root = root;
        this.body = root.getChild("body");
        this.head = this.body.getChild("head");
        this.rightArm = this.body.getChild("right_arm");
        this.leftArm = this.body.getChild("left_arm");
        this.rightLeg = root.getChild("right_leg");
        this.leftLeg = root.getChild("left_leg");
    }

    public static TexturedModelData getTexturedModelData() {
        ModelData data = new ModelData();
        ModelPartData rootData = data.getRoot();

        // Torso: pivote en la cadera (a 16 "pixeles" del suelo = 128 unidades x8).
        ModelPartData bodyData = rootData.addChild("body",
                ModelPartBuilder.create().uv(0, 160).cuboid(-20.0f, -112.0f, -12.0f, 40.0f, 112.0f, 24.0f),
                ModelTransform.pivot(0.0f, -128.0f, 0.0f));

        // Cabeza alargada (40 x 88 x 40), pivote en el cuello.
        bodyData.addChild("head",
                ModelPartBuilder.create().uv(0, 0).cuboid(-20.0f, -88.0f, -20.0f, 40.0f, 88.0f, 40.0f),
                ModelTransform.pivot(0.0f, -112.0f, 0.0f));

        // Brazos larguisimos (24 pixeles), pivote en los hombros.
        bodyData.addChild("right_arm",
                ModelPartBuilder.create().uv(230, 0).cuboid(-8.0f, 0.0f, -8.0f, 16.0f, 192.0f, 16.0f),
                ModelTransform.pivot(-28.0f, -96.0f, 0.0f));

        bodyData.addChild("left_arm",
                ModelPartBuilder.create().uv(300, 0).cuboid(-8.0f, 0.0f, -8.0f, 16.0f, 192.0f, 16.0f),
                ModelTransform.pivot(28.0f, -96.0f, 0.0f));

        // Piernas finas.
        rootData.addChild("right_leg",
                ModelPartBuilder.create().uv(370, 0).cuboid(-8.0f, 0.0f, -8.0f, 16.0f, 128.0f, 16.0f),
                ModelTransform.pivot(-8.0f, -128.0f, 0.0f));

        rootData.addChild("left_leg",
                ModelPartBuilder.create().uv(440, 0).cuboid(-8.0f, 0.0f, -8.0f, 16.0f, 128.0f, 16.0f),
                ModelTransform.pivot(8.0f, -128.0f, 0.0f));

        return TexturedModelData.of(data, 512, 512);
    }

    @Override
    public void setAngles(StalkerEntity entity, float limbAngle, float limbDistance,
                          float animationProgress, float headYaw, float headPitch) {
        final float t = animationProgress;
        final float rad = (float) (Math.PI / 180.0);
        final int state = entity.getHorrorState();

        // Marcha lenta y rigida
        final float walk = limbAngle * 0.45f;
        final float swing = limbDistance;

        rightLeg.pitch = MathHelper.cos(walk) * 0.9f * swing;
        leftLeg.pitch = MathHelper.cos(walk + MathHelper.PI) * 0.9f * swing;

        // Torso encorvado que respira
        body.pitch = 0.14f + swing * 0.25f + MathHelper.sin(t * 0.09f) * 0.02f;
        body.yaw = MathHelper.cos(walk) * 0.12f * swing;
        body.roll = 0.0f;

        // Cabeza: sigue tu posicion pero compensando el torso
        head.yaw = headYaw * rad - body.yaw;
        head.pitch = headPitch * rad - body.pitch * 0.6f;
        head.roll = 0.0f;

        // Brazos largos que cuelgan y se balancean despacio
        final float idle = MathHelper.sin(t * 0.06f) * 0.04f;
        rightArm.pitch = MathHelper.cos(walk + MathHelper.PI) * 0.5f * swing + idle;
        leftArm.pitch = MathHelper.cos(walk) * 0.5f * swing - idle;
        rightArm.yaw = 0.0f;
        leftArm.yaw = 0.0f;
        rightArm.roll = 0.08f + MathHelper.sin(t * 0.05f) * 0.03f;
        leftArm.roll = -0.08f - MathHelper.sin(t * 0.05f + 1.0f) * 0.03f;

        // Tics nerviosos de la cabeza, a rafagas
        if (MathHelper.sin(t * 0.045f) > 0.93f) {
            head.roll += MathHelper.sin(t * 2.7f) * 0.3f;
            head.yaw += MathHelper.sin(t * 3.9f) * 0.25f;
        }

        if (state == StalkerEntity.STATE_SEEN) {
            // Lo estas mirando: se congela y ladea la cabeza
            head.roll += 0.45f;
            head.pitch += 0.15f;
            rightArm.pitch = 0.08f;
            leftArm.pitch = 0.08f;
            rightArm.roll += 0.2f;
            leftArm.roll -= 0.2f;
        } else if (state == StalkerEntity.STATE_TAP) {
            // Manos pegadas al vidrio, golpeando
            final float tap = MathHelper.sin(t * 0.9f) * 0.09f;
            body.pitch = 0.2f;
            head.roll += 0.25f;
            rightArm.pitch = -1.45f + tap;
            leftArm.pitch = -1.45f - tap;
            rightArm.roll = 0.12f;
            leftArm.roll = -0.12f;
        } else if (state == StalkerEntity.STATE_REACH) {
            // Mete la mano para agarrarte
            body.pitch = 0.4f;
            head.pitch += 0.1f;
            rightArm.pitch = -1.55f + MathHelper.sin(t * 0.6f) * 0.06f;
            rightArm.yaw = -0.08f;
            rightArm.roll = 0.0f;
            leftArm.pitch = -0.6f;
        } else if (state == StalkerEntity.STATE_SCREAM) {
            // Grito: brazos arriba, cabeza hacia atras, temblando
            final float shake = MathHelper.sin(t * 3.2f);
            head.pitch = -0.7f + shake * 0.08f;
            head.yaw += shake * 0.2f;
            head.roll = 0.0f;
            rightArm.pitch = -2.6f + shake * 0.12f;
            leftArm.pitch = -2.6f - shake * 0.12f;
            rightArm.roll = 0.5f;
            leftArm.roll = -0.5f;
            body.pitch = -0.15f;
            body.yaw = shake * 0.08f;
        }
    }

    @Override
    public void render(MatrixStack matrices, VertexConsumer vertices, int light, int overlay,
                       float red, float green, float blue, float alpha) {
        matrices.push();
        // Los pies del modelo estan en y = 0; el renderer espera los pies a 24 pixeles (1.5 bloques).
        matrices.translate(0.0f, 1.5f, 0.0f);
        matrices.scale(1.0f / MODEL_SCALE, 1.0f / MODEL_SCALE, 1.0f / MODEL_SCALE);
        root.render(matrices, vertices, light, overlay, red, green, blue, alpha);
        matrices.pop();
    }
}
