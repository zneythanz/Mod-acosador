package com.stalkerhorror.client;

import com.stalkerhorror.StalkerHorror;
import com.stalkerhorror.entity.StalkerEntity;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.model.ModelData;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.model.ModelPartBuilder;
import net.minecraft.client.model.ModelPartData;
import net.minecraft.client.model.ModelTransform;
import net.minecraft.client.model.TexturedModelData;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.entity.model.EntityModel;
import net.minecraft.client.render.entity.model.EntityModelLayer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;

/**
 * Modelo del Acosador: muy alto, delgado, brazos larguisimos.
 * Solo 6 cubos (muy barato de dibujar) y las animaciones se calculan a mano,
 * sin librerias extra.
 *
 * Textura 64x64:
 *   cabeza (0,0)  cuerpo (0,16)  brazo der (24,16)  brazo izq (34,16)
 *   pierna der (0,38)  pierna izq (14,38)
 */
@Environment(EnvType.CLIENT)
public class StalkerModel extends EntityModel<StalkerEntity> {
    public static final EntityModelLayer LAYER =
            new EntityModelLayer(new Identifier(StalkerHorror.MOD_ID, "stalker"), "main");

    private final ModelPart root;
    private final ModelPart body;
    private final ModelPart head;
    private final ModelPart rightArm;
    private final ModelPart leftArm;
    private final ModelPart rightLeg;
    private final ModelPart leftLeg;

    public StalkerModel(ModelPart root) {
        this.root = root;
        this.body = root.getChild("body");
        this.head = this.body.getChild("head");
        this.rightArm = this.body.getChild("right_arm");
        this.leftArm = this.body.getChild("left_arm");
        this.rightLeg = root.getChild("right_leg");
        this.leftLeg = root.getChild("left_leg");
    }

    public static TexturedModelData getTexturedModelData() {
        ModelData data = new ModelData();
        ModelPartData rootData = data.getRoot();

        // Torso (la cabeza y los brazos cuelgan de el para que se muevan juntos al encorvarse)
        ModelPartData bodyData = rootData.addChild("body",
                ModelPartBuilder.create().uv(0, 16).cuboid(-3.0f, 0.0f, -1.5f, 6.0f, 12.0f, 3.0f),
                ModelTransform.pivot(0.0f, -2.0f, 0.0f));

        bodyData.addChild("head",
                ModelPartBuilder.create().uv(0, 0).cuboid(-3.0f, -8.0f, -3.0f, 6.0f, 8.0f, 6.0f),
                ModelTransform.pivot(0.0f, -1.0f, 0.0f));

        bodyData.addChild("right_arm",
                ModelPartBuilder.create().uv(24, 16).cuboid(-1.0f, -1.0f, -1.0f, 2.0f, 18.0f, 2.0f),
                ModelTransform.pivot(-4.0f, 1.0f, 0.0f));

        bodyData.addChild("left_arm",
                ModelPartBuilder.create().uv(34, 16).cuboid(-1.0f, -1.0f, -1.0f, 2.0f, 18.0f, 2.0f),
                ModelTransform.pivot(4.0f, 1.0f, 0.0f));

        rootData.addChild("right_leg",
                ModelPartBuilder.create().uv(0, 38).cuboid(-1.5f, 0.0f, -1.5f, 3.0f, 14.0f, 3.0f),
                ModelTransform.pivot(-1.5f, 10.0f, 0.0f));

        rootData.addChild("left_leg",
                ModelPartBuilder.create().uv(14, 38).cuboid(-1.5f, 0.0f, -1.5f, 3.0f, 14.0f, 3.0f),
                ModelTransform.pivot(1.5f, 10.0f, 0.0f));

        return TexturedModelData.of(data, 64, 64);
    }

    @Override
    public void setAngles(StalkerEntity entity, float limbAngle, float limbDistance,
                          float animationProgress, float headYaw, float headPitch) {
        final float t = animationProgress;
        final float rad = (float) (Math.PI / 180.0);

        // Marcha lenta y rigida
        final float walk = limbAngle * 0.45f;
        final float swing = limbDistance;

        rightLeg.pitch = MathHelper.cos(walk) * 0.9f * swing;
        leftLeg.pitch = MathHelper.cos(walk + MathHelper.PI) * 0.9f * swing;

        // Torso encorvado que respira
        body.pitch = 0.14f + swing * 0.25f + MathHelper.sin(t * 0.09f) * 0.02f;
        body.yaw = MathHelper.cos(walk) * 0.12f * swing;
        body.roll = 0.0f;

        // Cabeza: sigue tu posicion pero compensando el torso
        head.yaw = headYaw * rad - body.yaw;
        head.pitch = headPitch * rad - body.pitch * 0.6f;
        head.roll = 0.0f;

        // Brazos largos que cuelgan y se balancean despacio
        final float idle = MathHelper.sin(t * 0.06f) * 0.04f;
        rightArm.pitch = MathHelper.cos(walk + MathHelper.PI) * 0.5f * swing + idle;
        leftArm.pitch = MathHelper.cos(walk) * 0.5f * swing - idle;
        rightArm.yaw = 0.0f;
        leftArm.yaw = 0.0f;
        rightArm.roll = 0.08f + MathHelper.sin(t * 0.05f) * 0.03f;
        leftArm.roll = -0.08f - MathHelper.sin(t * 0.05f + 1.0f) * 0.03f;

        // Tics nerviosos de la cabeza, a rafagas
        if (MathHelper.sin(t * 0.045f) > 0.93f) {
            head.roll += MathHelper.sin(t * 2.7f) * 0.3f;
            head.yaw += MathHelper.sin(t * 3.9f) * 0.25f;
        }

        // Lo estas mirando: se congela y ladea la cabeza
        if (entity.isStaredAt()) {
            head.roll += 0.45f;
            head.pitch += 0.15f;
            rightArm.pitch = 0.08f;
            leftArm.pitch = 0.08f;
            rightArm.roll += 0.2f;
            leftArm.roll -= 0.2f;
        }

        // Grito: brazos arriba, cabeza hacia atras, temblando
        if (entity.isScreaming()) {
            final float shake = MathHelper.sin(t * 3.2f);
            head.pitch = -0.7f + shake * 0.08f;
            head.yaw += shake * 0.2f;
            head.roll = 0.0f;
            rightArm.pitch = -2.6f + shake * 0.12f;
            leftArm.pitch = -2.6f - shake * 0.12f;
            rightArm.roll = 0.5f;
            leftArm.roll = -0.5f;
            body.pitch = -0.15f;
            body.yaw = shake * 0.08f;
        }
    }

    @Override
    public void render(MatrixStack matrices, VertexConsumer vertices, int light, int overlay,
                       float red, float green, float blue, float alpha) {
        root.render(matrices, vertices, light, overlay, red, green, blue, alpha);
    }
}
