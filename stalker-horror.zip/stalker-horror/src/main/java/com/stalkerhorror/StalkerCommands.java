package com.stalkerhorror;

import com.mojang.brigadier.arguments.BoolArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.stalkerhorror.entity.StalkerEntity.Mode;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.command.CommandSource;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

import java.util.List;

/**
 * Comandos de prueba (necesitan trucos activados / OP nivel 2):
 *   /stalker spawn                  -> lo invoca al azar
 *   /stalker spawn acechar|ventana|puerta|detras
 *   /stalker grito                  -> grito lejano (el de las curvas)
 *   /stalker stage <0-5>            -> fase (mas fase = aparece mas cerca al acechar)
 *   /stalker clear                  -> lo quita del mundo
 *   /stalker natural <true|false>   -> activa/desactiva la aparicion natural
 */
public final class StalkerCommands {
    private StalkerCommands() {
    }

    private static int spawn(CommandContext<ServerCommandSource> ctx, String modeName) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        ServerPlayerEntity player = ctx.getSource().getPlayerOrThrow();
        Mode mode = null;
        switch (modeName) {
            case "acechar" -> mode = Mode.STALK;
            case "ventana" -> mode = Mode.WINDOW;
            case "puerta" -> mode = Mode.DOOR;
            case "detras" -> mode = Mode.BEHIND;
            default -> mode = null;
        }
        boolean ok = StalkerManager.forceSpawn(player, mode);
        String msg;
        if (ok) {
            msg = "El Acosador ya te está buscando...";
        } else if (mode == Mode.WINDOW) {
            msg = "No encontré una ventana de vidrio cerca con espacio afuera. Ponte dentro de una casa con ventanas.";
        } else if (mode == Mode.DOOR) {
            msg = "No encontré una puerta de madera cerrada cerca. Ponte dentro de una casa con puertas.";
        } else {
            msg = "No encontré sitio donde aparecer. Prueba en otro lugar.";
        }
        ctx.getSource().sendFeedback(() -> Text.literal(msg), false);
        return ok ? 1 : 0;
    }

    public static void register() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
                dispatcher.register(CommandManager.literal("stalker")
                        .requires(source -> source.hasPermissionLevel(2))

                        .then(CommandManager.literal("spawn")
                                .executes(ctx -> spawn(ctx, "azar"))
                                .then(CommandManager.argument("modo", StringArgumentType.word())
                                        .suggests((ctx, builder) -> CommandSource.suggestMatching(
                                                List.of("acechar", "ventana", "puerta", "detras"), builder))
                                        .executes(ctx -> spawn(ctx, StringArgumentType.getString(ctx, "modo")))))

                        .then(CommandManager.literal("grito").executes(ctx -> {
                            ServerPlayerEntity player = ctx.getSource().getPlayerOrThrow();
                            StalkerManager.cornerScream(player.getServerWorld(), player);
                            return 1;
                        }))

                        .then(CommandManager.literal("stage")
                                .then(CommandManager.argument("n", IntegerArgumentType.integer(0, StalkerConfig.MAX_STAGE))
                                        .executes(ctx -> {
                                            ServerPlayerEntity player = ctx.getSource().getPlayerOrThrow();
                                            int n = IntegerArgumentType.getInteger(ctx, "n");
                                            StalkerManager.setStage(player, n);
                                            ctx.getSource().sendFeedback(() -> Text.literal("Fase fijada en " + n), false);
                                            return n;
                                        })))

                        .then(CommandManager.literal("clear").executes(ctx -> {
                            StalkerManager.clearAll(ctx.getSource().getServer());
                            ctx.getSource().sendFeedback(() -> Text.literal("Acosadores eliminados."), false);
                            return 1;
                        }))

                        .then(CommandManager.literal("natural")
                                .then(CommandManager.argument("enabled", BoolArgumentType.bool())
                                        .executes(ctx -> {
                                            boolean enabled = BoolArgumentType.getBool(ctx, "enabled");
                                            StalkerManager.naturalSpawning = enabled;
                                            ctx.getSource().sendFeedback(() -> Text.literal(
                                                    "Aparición natural: " + (enabled ? "ACTIVADA" : "desactivada")), false);
                                            return 1;
                                        })))
                ));
    }
}
