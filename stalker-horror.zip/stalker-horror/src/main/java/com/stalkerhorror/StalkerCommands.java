package com.stalkerhorror;

import com.mojang.brigadier.arguments.BoolArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

/**
 * Comandos de prueba (necesitan trucos activados / OP nivel 2):
 *   /stalker spawn            -> lo invoca ahora mismo
 *   /stalker stage <0-5>      -> fija la fase (mas fase = aparece mas cerca)
 *   /stalker clear            -> lo quita del mundo
 *   /stalker natural <true|false> -> activa/desactiva la aparicion natural
 */
public final class StalkerCommands {
    private StalkerCommands() {
    }

    public static void register() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
                dispatcher.register(CommandManager.literal("stalker")
                        .requires(source -> source.hasPermissionLevel(2))

                        .then(CommandManager.literal("spawn").executes(ctx -> {
                            ServerPlayerEntity player = ctx.getSource().getPlayerOrThrow();
                            boolean ok = StalkerManager.forceSpawn(player);
                            ctx.getSource().sendFeedback(() -> Text.literal(
                                    ok ? "El Acosador ya te esta observando..." : "No encontre un sitio donde aparecer. Prueba en otro lugar."), false);
                            return ok ? 1 : 0;
                        }))

                        .then(CommandManager.literal("stage")
                                .then(CommandManager.argument("n", IntegerArgumentType.integer(0, StalkerConfig.MAX_STAGE))
                                        .executes(ctx -> {
                                            ServerPlayerEntity player = ctx.getSource().getPlayerOrThrow();
                                            int n = IntegerArgumentType.getInteger(ctx, "n");
                                            StalkerManager.setStage(player, n);
                                            ctx.getSource().sendFeedback(() -> Text.literal("Fase fijada en " + n), false);
                                            return n;
                                        })))

                        .then(CommandManager.literal("clear").executes(ctx -> {
                            StalkerManager.clearAll(ctx.getSource().getServer());
                            ctx.getSource().sendFeedback(() -> Text.literal("Acosadores eliminados."), false);
                            return 1;
                        }))

                        .then(CommandManager.literal("natural")
                                .then(CommandManager.argument("enabled", BoolArgumentType.bool())
                                        .executes(ctx -> {
                                            boolean enabled = BoolArgumentType.getBool(ctx, "enabled");
                                            StalkerManager.naturalSpawning = enabled;
                                            ctx.getSource().sendFeedback(() -> Text.literal(
                                                    "Aparicion natural: " + (enabled ? "ACTIVADA" : "desactivada")), false);
                                            return 1;
                                        })))
                ));
    }
}
