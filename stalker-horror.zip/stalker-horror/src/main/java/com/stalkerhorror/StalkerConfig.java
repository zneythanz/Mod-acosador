package com.stalkerhorror;

/**
 * Ajustes del mod. Cambia los numeros y vuelve a compilar.
 * (1 segundo = 20 ticks)
 */
public final class StalkerConfig {
    private StalkerConfig() {
    }

    // ---- Aparicion ----
    /** Si es false, solo aparece con el comando /stalker spawn. */
    public static final boolean NATURAL_SPAWNING = true;
    /** Tiempo de calma al entrar al mundo antes de la primera aparicion. */
    public static final int FIRST_SPAWN_DELAY_TICKS = 20 * 60;
    /** Probabilidad por segundo de que aparezca cuando hay oscuridad y ya paso la calma. */
    public static final double SPAWN_CHANCE_PER_SECOND = 0.05;
    /** Distancia de aparicion en la fase 0 (bloques). */
    public static final double START_SPAWN_DISTANCE = 38.0;
    /** Cuanto mas cerca aparece en cada fase nueva. */
    public static final double DISTANCE_STEP = 5.0;
    public static final double MIN_SPAWN_DISTANCE = 14.0;
    public static final int MAX_STAGE = 5;

    // ---- Comportamiento ----
    /** Si esta mas lejos que esto desaparece en silencio. */
    public static final double MAX_DISTANCE = 100.0;
    /** Si dura tanto sin resolverse, desaparece y sube de fase. */
    public static final int MAX_LIFETIME_TICKS = 20 * 240;
    /** Velocidad al acercarse cuando no lo miras (multiplicador). */
    public static final double CREEP_SPEED = 0.9;
    public static final double SPEED_PER_STAGE = 0.12;
    /** Extra de velocidad cuando esta a menos de 14 bloques y no lo miras. */
    public static final double CLOSE_SPEED_BONUS = 1.35;

    /** Ticks que puedes mirarlo (de lejos) antes de que desaparezca y vuelva mas cerca. */
    public static final int STARE_LIMIT_TICKS = 70;
    public static final int STARE_LIMIT_STEP = 8;
    public static final int MIN_STARE_LIMIT_TICKS = 30;
    /** Si lo miras tanto estando cerca (<= 8 bloques), pierde la paciencia y te ataca. */
    public static final int CLOSE_STARE_PATIENCE_TICKS = 160;

    /** Cuan centrado debe estar en tu vista para contar como "mirado" (1.0 = justo al centro). */
    public static final double LOOK_DOT_NEAR = 0.82;
    public static final double LOOK_DOT_FAR = 0.93;

    // ---- Susto ----
    public static final double JUMPSCARE_DISTANCE = 3.2;
    public static final int SCREAM_TICKS = 30;
    public static final float ATTACK_DAMAGE = 5.0f;
    /** Pulsos de oscuridad (efecto Darkness) cuando esta cerca en fases altas. */
    public static final boolean DARKNESS_PULSE = true;
}
