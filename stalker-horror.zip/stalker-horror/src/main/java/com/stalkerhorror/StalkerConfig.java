package com.stalkerhorror;

/**
 * Ajustes del mod. Cambia los numeros y vuelve a compilar.
 * (1 segundo = 20 ticks)
 */
public final class StalkerConfig {
    private StalkerConfig() {
    }

    // ---- Aparicion ----
    /** Si es false, solo aparece con el comando /stalker spawn. */
    public static final boolean NATURAL_SPAWNING = true;
    /** Calma al entrar al mundo antes de la primera aparicion. */
    public static final int FIRST_SPAWN_DELAY_TICKS = 20 * 60;
    /** Probabilidad por segundo de que aparezca (de noche, en cuevas o en interiores oscuros). */
    public static final double SPAWN_CHANCE_PER_SECOND = 0.05;
    public static final double START_SPAWN_DISTANCE = 38.0;
    public static final double DISTANCE_STEP = 5.0;
    public static final double MIN_SPAWN_DISTANCE = 14.0;
    public static final int MAX_STAGE = 5;

    // ---- Comportamiento general ----
    public static final double MAX_DISTANCE = 100.0;
    /** Duracion maxima segun el modo (ticks). */
    public static final int LIFE_STALK = 20 * 240;
    public static final int LIFE_WINDOW = 20 * 120;
    public static final int LIFE_DOOR = 20 * 90;
    public static final int LIFE_BEHIND = 20 * 45;

    // ---- Modo "acechar" (se acerca cuando no lo miras) ----
    public static final double CREEP_SPEED = 0.9;
    public static final double SPEED_PER_STAGE = 0.12;
    public static final double CLOSE_SPEED_BONUS = 1.35;
    public static final int STARE_LIMIT_TICKS = 70;
    public static final int STARE_LIMIT_STEP = 8;
    public static final int MIN_STARE_LIMIT_TICKS = 30;
    public static final int CLOSE_STARE_PATIENCE_TICKS = 160;
    public static final double LOOK_DOT_NEAR = 0.82;
    public static final double LOOK_DOT_FAR = 0.93;

    // ---- Puerta: abre, mete la mano y te agarra ----
    /** A cuantos bloques de ti tiene que quedar para agarrarte. */
    public static final double REACH_GRAB_DISTANCE = 2.6;

    // ---- Susto ----
    public static final double JUMPSCARE_DISTANCE = 3.2;
    public static final int SCREAM_TICKS = 30;
    public static final float ATTACK_DAMAGE = 5.0f;
    public static final boolean DARKNESS_PULSE = true;

    // ---- Gritos en las curvas (cuando giras la cabeza de golpe) ----
    public static final float CORNER_YAW_DEGREES = 70.0f;
    public static final double CORNER_SCREAM_CHANCE = 0.35;
    public static final int CORNER_COOLDOWN_SECONDS = 45;
}
