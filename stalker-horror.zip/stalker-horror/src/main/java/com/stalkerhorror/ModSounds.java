package com.stalkerhorror;

import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;

public final class ModSounds {
    public static final SoundEvent BREATH = register("stalker.breath");
    public static final SoundEvent WHISPER = register("stalker.whisper");
    public static final SoundEvent SCREAM = register("stalker.scream");
    public static final SoundEvent DRONE = register("stalker.drone");

    private ModSounds() {
    }

    private static SoundEvent register(String name) {
        Identifier id = new Identifier(StalkerHorror.MOD_ID, name);
        return Registry.register(Registries.SOUND_EVENT, id, SoundEvent.of(id));
    }

    public static void register() {
        // Solo fuerza la carga de la clase (y con ella el registro de los sonidos).
    }
}
