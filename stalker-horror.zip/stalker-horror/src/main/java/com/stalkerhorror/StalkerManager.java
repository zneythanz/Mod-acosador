package com.stalkerhorror;

import com.stalkerhorror.entity.StalkerEntity;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.block.BlockState;
import net.minecraft.entity.Entity;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

/**
 * Decide cuando y donde aparece el Acosador y recuerda en que "fase" va cada jugador.
 * Cada fase nueva lo hace aparecer mas cerca.
 */
public final class StalkerManager {
    public enum Reason {
        /** Lo miraste demasiado: vuelve mas cerca. */
        STARED_AT,
        /** Te ataco: todo se reinicia con una calma larga. */
        ATTACKED,
        /** Lo golpeaste y huyo. */
        SCARED,
        /** Desaparecio sin mas (muy lejos, etc.). */
        QUIET
    }

    private static final class PlayerState {
        int stage = 0;
        int cooldown = StalkerConfig.FIRST_SPAWN_DELAY_TICKS;
        UUID stalkerId = null;
    }

    private static final Map<UUID, PlayerState> STATES = new HashMap<>();
    private static final Random RANDOM = new Random();

    /** Se puede cambiar en juego con /stalker natural true|false */
    public static boolean naturalSpawning = StalkerConfig.NATURAL_SPAWNING;

    private StalkerManager() {
    }

    public static void register() {
        ServerTickEvents.END_WORLD_TICK.register(StalkerManager::tick);
        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> STATES.remove(handler.getPlayer().getUuid()));
        ServerLifecycleEvents.SERVER_STOPPED.register(server -> STATES.clear());
    }

    private static PlayerState state(ServerPlayerEntity player) {
        return STATES.computeIfAbsent(player.getUuid(), id -> new PlayerState());
    }

    // ------------------------------------------------------------------
    // Bucle principal (1 vez por segundo)
    // ------------------------------------------------------------------
    private static void tick(ServerWorld world) {
        if (world.getRegistryKey() != World.OVERWORLD) return;
        if (world.getTime() % 20 != 0) return;

        for (ServerPlayerEntity player : world.getPlayers()) {
            if (player.isSpectator() || !player.isAlive()) continue;

            PlayerState st = state(player);

            if (st.stalkerId != null) {
                Entity existing = world.getEntity(st.stalkerId);
                if (existing instanceof StalkerEntity && existing.isAlive()) {
                    continue; // el Acosador se encarga solo
                }
                st.stalkerId = null;
                st.cooldown = Math.max(st.cooldown, 400);
                continue;
            }

            if (st.cooldown > 0) {
                st.cooldown -= 20;
                continue;
            }

            if (!naturalSpawning || !isSpooky(world, player)) continue;

            if (world.random.nextDouble() < StalkerConfig.SPAWN_CHANCE_PER_SECOND) {
                if (!spawnFor(world, player, st, true)) {
                    st.cooldown = 100; // no encontro sitio, reintenta pronto
                }
            }
        }
    }

    /** Hay oscuridad (noche, cuevas, interiores sin luz). */
    private static boolean isSpooky(ServerWorld world, ServerPlayerEntity player) {
        long timeOfDay = world.getTimeOfDay() % 24000L;
        boolean night = timeOfDay >= 13000L && timeOfDay <= 23000L;
        int light = world.getLightLevel(player.getBlockPos());
        return night || light <= 7;
    }

    // ------------------------------------------------------------------
    // Aparicion
    // ------------------------------------------------------------------
    private static boolean spawnFor(ServerWorld world, ServerPlayerEntity player, PlayerState st, boolean requireHidden) {
        double baseDistance = Math.max(StalkerConfig.MIN_SPAWN_DISTANCE,
                StalkerConfig.START_SPAWN_DISTANCE - st.stage * StalkerConfig.DISTANCE_STEP);
        Vec3d look = player.getRotationVec(1.0f).normalize();

        for (int attempt = 0; attempt < 40; attempt++) {
            double angle = world.random.nextDouble() * Math.PI * 2.0;
            double distance = baseDistance + (world.random.nextDouble() - 0.5) * 6.0;
            int x = MathHelper.floor(player.getX() + Math.cos(angle) * distance);
            int z = MathHelper.floor(player.getZ() + Math.sin(angle) * distance);

            if (!world.getChunkManager().isChunkLoaded(x >> 4, z >> 4)) continue;

            BlockPos ground = findStandingSpot(world, x, z, player.getBlockY());
            if (ground == null) continue;

            Vec3d spot = new Vec3d(x + 0.5, ground.getY(), z + 0.5);

            // Que aparezca fuera de tu campo de vision: lo descubres al girarte.
            if (requireHidden) {
                Vec3d toSpot = spot.add(0, 1.4, 0).subtract(player.getEyePos()).normalize();
                if (look.dotProduct(toSpot) > 0.25) continue;
            }

            StalkerEntity stalker = ModEntities.STALKER.create(world);
            if (stalker == null) return false;

            float yaw = (float) (MathHelper.atan2(player.getZ() - spot.z, player.getX() - spot.x) * 180.0 / Math.PI) - 90.0f;
            stalker.refreshPositionAndAngles(spot.x, spot.y, spot.z, yaw, 0.0f);
            stalker.bindTarget(player.getUuid(), st.stage);
            stalker.setPersistent();
            world.spawnEntity(stalker);

            st.stalkerId = stalker.getUuid();
            world.playSound(null, player.getX(), player.getY(), player.getZ(),
                    ModSounds.DRONE, SoundCategory.AMBIENT, 1.0f, 1.0f);
            return true;
        }
        return false;
    }

    private static BlockPos findStandingSpot(ServerWorld world, int x, int z, int aroundY) {
        BlockPos.Mutable pos = new BlockPos.Mutable();
        for (int y = aroundY + 3; y >= aroundY - 8; y--) {
            pos.set(x, y, z);
            BlockPos below = pos.down();
            BlockState belowState = world.getBlockState(below);
            if (belowState.isSideSolidFullSquare(world, below, Direction.UP)
                    && isFree(world, pos)
                    && isFree(world, pos.up())
                    && isFree(world, pos.up(2))) {
                return pos.toImmutable();
            }
        }
        return null;
    }

    private static boolean isFree(ServerWorld world, BlockPos pos) {
        return world.getBlockState(pos).getCollisionShape(world, pos).isEmpty()
                && world.getFluidState(pos).isEmpty();
    }

    // ------------------------------------------------------------------
    // API para el Acosador y los comandos
    // ------------------------------------------------------------------
    public static void notifyGone(UUID playerId, Reason reason) {
        if (playerId == null) return;
        PlayerState st = STATES.get(playerId);
        if (st == null) return;
        st.stalkerId = null;
        switch (reason) {
            case STARED_AT -> {
                st.stage = Math.min(st.stage + 1, StalkerConfig.MAX_STAGE);
                st.cooldown = 200 + RANDOM.nextInt(300);
            }
            case ATTACKED -> {
                st.stage = 0;
                st.cooldown = 20 * 180 + RANDOM.nextInt(20 * 180);
            }
            case SCARED -> st.cooldown = 600 + RANDOM.nextInt(600);
            case QUIET -> st.cooldown = 300 + RANDOM.nextInt(300);
        }
    }

    public static boolean forceSpawn(ServerPlayerEntity player) {
        ServerWorld world = player.getServerWorld();
        PlayerState st = state(player);
        discardCurrent(world, st);
        return spawnFor(world, player, st, true) || spawnFor(world, player, st, false);
    }

    public static void setStage(ServerPlayerEntity player, int stage) {
        state(player).stage = MathHelper.clamp(stage, 0, StalkerConfig.MAX_STAGE);
    }

    public static void clearAll(MinecraftServer server) {
        for (ServerWorld world : server.getWorlds()) {
            for (StalkerEntity stalker : world.getEntitiesByType(ModEntities.STALKER, e -> true)) {
                stalker.discard();
            }
        }
        for (PlayerState st : STATES.values()) {
            st.stalkerId = null;
            st.cooldown = 600;
        }
    }

    private static void discardCurrent(ServerWorld world, PlayerState st) {
        if (st.stalkerId != null) {
            Entity e = world.getEntity(st.stalkerId);
            if (e != null) e.discard();
            st.stalkerId = null;
        }
    }
}
