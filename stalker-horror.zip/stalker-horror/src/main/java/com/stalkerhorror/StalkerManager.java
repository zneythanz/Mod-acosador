package com.stalkerhorror;

import com.stalkerhorror.entity.StalkerEntity;
import com.stalkerhorror.entity.StalkerEntity.Mode;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.block.AbstractGlassBlock;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.DoorBlock;
import net.minecraft.block.PaneBlock;
import net.minecraft.block.enums.DoubleBlockHalf;
import net.minecraft.entity.Entity;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

/**
 * Decide cuando, donde y de que forma aparece el Acosador, y recuerda la "fase" de cada jugador.
 * Tambien genera los gritos lejanos cuando giras la cabeza de golpe ("gritos en las curvas").
 */
public final class StalkerManager {
    public enum Reason {
        /** Lo miraste demasiado: vuelve mas cerca. */
        STARED_AT,
        /** Te ataco: todo se reinicia con una calma larga. */
        ATTACKED,
        /** Lo golpeaste y huyo. */
        SCARED,
        /** Desaparecio sin mas (muy lejos, etc.). */
        QUIET,
        /** Termino su numero (ventana, puerta, detras). */
        DONE
    }

    private static final class PlayerState {
        int stage = 0;
        int cooldown = StalkerConfig.FIRST_SPAWN_DELAY_TICKS / 20;
        UUID stalkerId = null;
        float lastYaw;
        boolean yawInit;
        int cornerCd;
    }

    private record Spot(BlockPos spot, BlockPos extra) {
    }

    private static final Map<UUID, PlayerState> STATES = new HashMap<>();
    private static final Random RANDOM = new Random();

    /** Se puede cambiar en juego con /stalker natural true|false */
    public static boolean naturalSpawning = StalkerConfig.NATURAL_SPAWNING;

    private StalkerManager() {
    }

    public static void register() {
        ServerTickEvents.END_WORLD_TICK.register(StalkerManager::tick);
        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> STATES.remove(handler.getPlayer().getUuid()));
        ServerLifecycleEvents.SERVER_STOPPED.register(server -> STATES.clear());
    }

    private static PlayerState state(ServerPlayerEntity player) {
        return STATES.computeIfAbsent(player.getUuid(), id -> new PlayerState());
    }

    // ------------------------------------------------------------------
    // Bucle principal (1 vez por segundo)
    // ------------------------------------------------------------------
    private static void tick(ServerWorld world) {
        if (world.getRegistryKey() != World.OVERWORLD) return;
        if (world.getTime() % 20 != 0) return;

        for (ServerPlayerEntity player : world.getPlayers()) {
            if (player.isSpectator() || !player.isAlive()) continue;

            PlayerState st = state(player);
            cornerCheck(world, player, st);

            if (st.stalkerId != null) {
                Entity existing = world.getEntity(st.stalkerId);
                if (existing instanceof StalkerEntity && existing.isAlive()) {
                    continue;
                }
                st.stalkerId = null;
                st.cooldown = Math.max(st.cooldown, 20);
                continue;
            }

            if (st.cooldown > 0) {
                st.cooldown -= 1;
                continue;
            }

            if (!naturalSpawning || !isSpooky(world, player)) continue;

            if (world.random.nextDouble() < StalkerConfig.SPAWN_CHANCE_PER_SECOND) {
                if (!spawnAny(world, player, st)) {
                    st.cooldown = 5;
                }
            }
        }
    }

    /** Hay oscuridad (noche, cuevas, interiores sin luz). */
    private static boolean isSpooky(ServerWorld world, ServerPlayerEntity player) {
        long timeOfDay = world.getTimeOfDay() % 24000L;
        boolean night = timeOfDay >= 13000L && timeOfDay <= 23000L;
        int light = world.getLightLevel(player.getBlockPos());
        return night || light <= 7;
    }

    // ------------------------------------------------------------------
    // Gritos en las curvas
    // ------------------------------------------------------------------
    private static void cornerCheck(ServerWorld world, ServerPlayerEntity player, PlayerState st) {
        float yaw = player.getYaw();
        if (st.cornerCd > 0) st.cornerCd--;
        if (st.yawInit) {
            float delta = Math.abs(MathHelper.wrapDegrees(yaw - st.lastYaw));
            if (delta > StalkerConfig.CORNER_YAW_DEGREES
                    && st.cornerCd <= 0
                    && naturalSpawning
                    && isSpooky(world, player)
                    && RANDOM.nextDouble() < StalkerConfig.CORNER_SCREAM_CHANCE) {
                cornerScream(world, player);
                st.cornerCd = StalkerConfig.CORNER_COOLDOWN_SECONDS;
            }
        }
        st.lastYaw = yaw;
        st.yawInit = true;
    }

    /** Un grito lejano, hacia donde miras (con algo de desvio), como si viniera del fondo del pasillo. */
    public static void cornerScream(ServerWorld world, ServerPlayerEntity player) {
        Vec3d look = player.getRotationVec(1.0f);
        double base = Math.atan2(look.z, look.x) + (RANDOM.nextDouble() - 0.5) * 2.0;
        double dist = 18.0 + RANDOM.nextDouble() * 10.0;
        double x = player.getX() + Math.cos(base) * dist;
        double z = player.getZ() + Math.sin(base) * dist;
        world.playSound(null, x, player.getY(), z, ModSounds.SCREAM_FAR, SoundCategory.HOSTILE,
                3.0f, 0.85f + RANDOM.nextFloat() * 0.3f);
    }

    // ------------------------------------------------------------------
    // Aparicion
    // ------------------------------------------------------------------
    private static List<Mode> modeOrder(ServerWorld world, ServerPlayerEntity player) {
        boolean indoors = !world.isSkyVisible(player.getBlockPos());
        List<Mode> pool = new ArrayList<>();
        if (indoors) {
            addCopies(pool, Mode.WINDOW, 3);
            addCopies(pool, Mode.DOOR, 2);
            addCopies(pool, Mode.BEHIND, 2);
            addCopies(pool, Mode.STALK, 1);
        } else {
            addCopies(pool, Mode.BEHIND, 2);
            addCopies(pool, Mode.STALK, 3);
        }
        Collections.shuffle(pool, RANDOM);
        return new ArrayList<>(new LinkedHashSet<>(pool));
    }

    private static void addCopies(List<Mode> list, Mode mode, int n) {
        for (int i = 0; i < n; i++) list.add(mode);
    }

    private static boolean spawnAny(ServerWorld world, ServerPlayerEntity player, PlayerState st) {
        for (Mode mode : modeOrder(world, player)) {
            if (spawn(world, player, st, mode)) return true;
        }
        return false;
    }

    private static boolean spawn(ServerWorld world, ServerPlayerEntity player, PlayerState st, Mode mode) {
        return switch (mode) {
            case WINDOW -> spawnWindow(world, player, st);
            case DOOR -> spawnDoor(world, player, st);
            case BEHIND -> spawnBehind(world, player, st);
            default -> spawnStalk(world, player, st, true);
        };
    }

    private static boolean place(ServerWorld world, ServerPlayerEntity player, PlayerState st, Mode mode,
                                 Vec3d pos, BlockPos door, BlockPos glass) {
        StalkerEntity e = ModEntities.STALKER.create(world);
        if (e == null) return false;
        float yaw = (float) (MathHelper.atan2(player.getZ() - pos.z, player.getX() - pos.x) * 180.0 / Math.PI) - 90.0f;
        e.refreshPositionAndAngles(pos.x, pos.y, pos.z, yaw, 0.0f);
        e.bind(player.getUuid(), st.stage, mode, door, glass);
        e.setPersistent();
        world.spawnEntity(e);
        st.stalkerId = e.getUuid();
        world.playSound(null, player.getX(), player.getY(), player.getZ(),
                ModSounds.DRONE, SoundCategory.AMBIENT, 1.0f, 1.0f);
        return true;
    }

    // --- ACECHAR: lejos, fuera de tu vista ---
    private static boolean spawnStalk(ServerWorld world, ServerPlayerEntity player, PlayerState st, boolean requireHidden) {
        double baseDistance = Math.max(StalkerConfig.MIN_SPAWN_DISTANCE,
                StalkerConfig.START_SPAWN_DISTANCE - st.stage * StalkerConfig.DISTANCE_STEP);
        Vec3d look = player.getRotationVec(1.0f).normalize();

        for (int attempt = 0; attempt < 40; attempt++) {
            double angle = world.random.nextDouble() * Math.PI * 2.0;
            double distance = baseDistance + (world.random.nextDouble() - 0.5) * 6.0;
            int x = MathHelper.floor(player.getX() + Math.cos(angle) * distance);
            int z = MathHelper.floor(player.getZ() + Math.sin(angle) * distance);
            if (!world.getChunkManager().isChunkLoaded(x >> 4, z >> 4)) continue;

            BlockPos ground = findStandingSpot(world, x, z, player.getBlockY());
            if (ground == null) continue;

            Vec3d spot = new Vec3d(x + 0.5, ground.getY(), z + 0.5);
            if (requireHidden) {
                Vec3d toSpot = spot.add(0, 1.4, 0).subtract(player.getEyePos()).normalize();
                if (look.dotProduct(toSpot) > 0.25) continue;
            }
            return place(world, player, st, Mode.STALK, spot, null, null);
        }
        return false;
    }

    // --- DETRAS: de verdad a tu espalda ---
    private static boolean spawnBehind(ServerWorld world, ServerPlayerEntity player, PlayerState st) {
        Vec3d look = player.getRotationVec(1.0f);
        Vec3d flat = new Vec3d(look.x, 0.0, look.z);
        if (flat.lengthSquared() < 1.0E-4) return false;
        flat = flat.normalize();

        double[] distances = {2.8, 3.4, 2.4, 4.0, 3.0};
        for (double d : distances) {
            int x = MathHelper.floor(player.getX() - flat.x * d);
            int z = MathHelper.floor(player.getZ() - flat.z * d);
            BlockPos ground = findStandingSpot(world, x, z, player.getBlockY());
            if (ground == null) continue;
            if (Math.abs(ground.getY() - player.getBlockY()) > 1) continue;
            return place(world, player, st, Mode.BEHIND, new Vec3d(x + 0.5, ground.getY(), z + 0.5), null, null);
        }
        return false;
    }

    // --- VENTANA: afuera, pegado al vidrio ---
    private static boolean spawnWindow(ServerWorld world, ServerPlayerEntity player, PlayerState st) {
        BlockPos o = player.getBlockPos();
        List<Spot> found = new ArrayList<>();
        for (int dx = -14; dx <= 14; dx++) {
            for (int dz = -14; dz <= 14; dz++) {
                int d2 = dx * dx + dz * dz;
                if (d2 < 9 || d2 > 196) continue;
                if (!world.getChunkManager().isChunkLoaded((o.getX() + dx) >> 4, (o.getZ() + dz) >> 4)) continue;
                for (int dy = -1; dy <= 3; dy++) {
                    BlockPos p = o.add(dx, dy, dz);
                    if (!isGlass(world.getBlockState(p))) continue;
                    Spot s = windowSpotFor(world, player, p);
                    if (s != null) found.add(s);
                }
            }
        }
        if (found.isEmpty()) return false;
        Spot pick = found.get(RANDOM.nextInt(found.size()));
        Vec3d pos = new Vec3d(pick.spot().getX() + 0.5, pick.spot().getY(), pick.spot().getZ() + 0.5);
        return place(world, player, st, Mode.WINDOW, pos, null, pick.extra());
    }

    private static boolean isGlass(BlockState s) {
        return s.getBlock() instanceof AbstractGlassBlock
                || (s.getBlock() instanceof PaneBlock && !s.isOf(Blocks.IRON_BARS));
    }

    private static Spot windowSpotFor(ServerWorld world, ServerPlayerEntity player, BlockPos glass) {
        Vec3d d = Vec3d.ofCenter(glass).subtract(player.getPos());
        Direction xDir = d.x > 0 ? Direction.EAST : Direction.WEST;
        Direction zDir = d.z > 0 ? Direction.SOUTH : Direction.NORTH;
        Direction[] dirs = Math.abs(d.x) > Math.abs(d.z)
                ? new Direction[]{xDir, zDir}
                : new Direction[]{zDir, xDir};

        for (Direction dir : dirs) {
            BlockPos inside = glass.offset(dir.getOpposite());
            if (!(isFree(world, inside) && isFree(world, inside.up()))) continue; // cuarto de tu lado
            BlockPos outside = glass.offset(dir);
            for (int k = 0; k <= 2; k++) {
                BlockPos spot = outside.down(k);
                if (standable(world, spot)
                        && Vec3d.ofCenter(spot).distanceTo(player.getPos()) >= 3.5) {
                    return new Spot(spot, glass);
                }
            }
        }
        return null;
    }

    // --- PUERTA: detras de una puerta de madera cerrada ---
    private static boolean spawnDoor(ServerWorld world, ServerPlayerEntity player, PlayerState st) {
        BlockPos o = player.getBlockPos();
        Vec3d pc = player.getPos();
        List<Spot> found = new ArrayList<>();
        for (int dx = -14; dx <= 14; dx++) {
            for (int dz = -14; dz <= 14; dz++) {
                int d2 = dx * dx + dz * dz;
                if (d2 < 16 || d2 > 196) continue;
                if (!world.getChunkManager().isChunkLoaded((o.getX() + dx) >> 4, (o.getZ() + dz) >> 4)) continue;
                for (int dy = -1; dy <= 2; dy++) {
                    BlockPos p = o.add(dx, dy, dz);
                    BlockState s = world.getBlockState(p);
                    if (!(s.getBlock() instanceof DoorBlock) || !s.isIn(BlockTags.WOODEN_DOORS)) continue;
                    if (s.get(DoorBlock.HALF) != DoubleBlockHalf.LOWER || s.get(DoorBlock.OPEN)) continue;

                    Direction f = s.get(DoorBlock.FACING);
                    BlockPos a = p.offset(f);
                    BlockPos b = p.offset(f.getOpposite());
                    BlockPos far = Vec3d.ofCenter(a).squaredDistanceTo(pc) > Vec3d.ofCenter(b).squaredDistanceTo(pc) ? a : b;
                    if (standable(world, far)) found.add(new Spot(far, p));
                }
            }
        }
        if (found.isEmpty()) return false;
        Spot pick = found.get(RANDOM.nextInt(found.size()));
        Vec3d pos = new Vec3d(pick.spot().getX() + 0.5, pick.spot().getY(), pick.spot().getZ() + 0.5);
        return place(world, player, st, Mode.DOOR, pos, pick.extra(), null);
    }

    // ------------------------------------------------------------------
    // Utilidades de terreno
    // ------------------------------------------------------------------
    private static BlockPos findStandingSpot(ServerWorld world, int x, int z, int aroundY) {
        BlockPos.Mutable pos = new BlockPos.Mutable();
        for (int y = aroundY + 3; y >= aroundY - 8; y--) {
            pos.set(x, y, z);
            if (standable(world, pos)) return pos.toImmutable();
        }
        return null;
    }

    /** Tres bloques libres de alto y suelo solido debajo. */
    private static boolean standable(ServerWorld world, BlockPos pos) {
        BlockPos below = pos.down();
        return world.getBlockState(below).isSideSolidFullSquare(world, below, Direction.UP)
                && isFree(world, pos)
                && isFree(world, pos.up())
                && isFree(world, pos.up(2));
    }

    private static boolean isFree(ServerWorld world, BlockPos pos) {
        return world.getBlockState(pos).getCollisionShape(world, pos).isEmpty()
                && world.getFluidState(pos).isEmpty();
    }

    // ------------------------------------------------------------------
    // API para el Acosador y los comandos
    // ------------------------------------------------------------------
    public static void notifyGone(UUID playerId, Reason reason) {
        if (playerId == null) return;
        PlayerState st = STATES.get(playerId);
        if (st == null) return;
        st.stalkerId = null;
        switch (reason) {
            case STARED_AT -> {
                st.stage = Math.min(st.stage + 1, StalkerConfig.MAX_STAGE);
                st.cooldown = 10 + RANDOM.nextInt(15);
            }
            case ATTACKED -> {
                st.stage = 0;
                st.cooldown = 120 + RANDOM.nextInt(120);
            }
            case SCARED -> st.cooldown = 30 + RANDOM.nextInt(30);
            case DONE -> st.cooldown = 40 + RANDOM.nextInt(50);
            case QUIET -> st.cooldown = 15 + RANDOM.nextInt(15);
        }
    }

    /** Para /stalker spawn. mode == null = al azar. */
    public static boolean forceSpawn(ServerPlayerEntity player, Mode mode) {
        ServerWorld world = player.getServerWorld();
        PlayerState st = state(player);
        discardCurrent(world, st);
        if (mode == null) {
            return spawnAny(world, player, st) || spawnStalk(world, player, st, false);
        }
        boolean ok = spawn(world, player, st, mode);
        if (!ok && mode == Mode.STALK) ok = spawnStalk(world, player, st, false);
        return ok;
    }

    public static void setStage(ServerPlayerEntity player, int stage) {
        state(player).stage = MathHelper.clamp(stage, 0, StalkerConfig.MAX_STAGE);
    }

    public static void clearAll(MinecraftServer server) {
        for (ServerWorld world : server.getWorlds()) {
            for (StalkerEntity stalker : world.getEntitiesByType(ModEntities.STALKER, e -> true)) {
                stalker.discard();
            }
        }
        for (PlayerState st : STATES.values()) {
            st.stalkerId = null;
            st.cooldown = 10;
        }
    }

    private static void discardCurrent(ServerWorld world, PlayerState st) {
        if (st.stalkerId != null) {
            Entity e = world.getEntity(st.stalkerId);
            if (e != null) e.discard();
            st.stalkerId = null;
        }
    }
}
