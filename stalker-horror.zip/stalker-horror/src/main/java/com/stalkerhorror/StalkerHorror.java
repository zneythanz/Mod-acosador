package com.stalkerhorror;

import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class StalkerHorror implements ModInitializer {
    public static final String MOD_ID = "stalkerhorror";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        ModSounds.register();
        ModEntities.register();
        StalkerManager.register();
        StalkerCommands.register();
        LOGGER.info("Stalker Horror cargado. No mires atras.");
    }
}
