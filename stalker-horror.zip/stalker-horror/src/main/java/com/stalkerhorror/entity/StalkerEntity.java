package com.stalkerhorror.entity;

import com.stalkerhorror.ModSounds;
import com.stalkerhorror.StalkerConfig;
import com.stalkerhorror.StalkerManager;
import net.minecraft.block.BlockState;
import net.minecraft.block.DoorBlock;
import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.EntityPose;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.damage.DamageTypes;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.mob.PathAwareEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

import java.util.UUID;

/**
 * El Acosador. Tiene cuatro formas de buscarte (modos):
 *
 *  ACECHAR  - te sigue: se congela si lo miras y se acerca si no.
 *  VENTANA  - aparece afuera, pegado al vidrio, te observa, golpea el cristal y grita.
 *  PUERTA   - espera detras de una puerta, la abre ("mira detras de la puerta"),
 *             mete la mano hacia ti y, si estas cerca, te agarra.
 *  DETRAS   - aparece de verdad a tu espalda y te susurra "estoy detras de ti".
 *
 * Toda la IA corre en el servidor; el cliente solo recibe un numero (el estado) para animar.
 */
public class StalkerEntity extends PathAwareEntity {
    public static final int STATE_IDLE = 0;
    public static final int STATE_SEEN = 1;
    public static final int STATE_SCREAM = 2;
    public static final int STATE_TAP = 3;
    public static final int STATE_REACH = 4;

    public enum Mode { STALK, WINDOW, DOOR, BEHIND }

    private static final TrackedData<Integer> STATE =
            DataTracker.registerData(StalkerEntity.class, TrackedDataHandlerRegistry.INTEGER);

    private static final String[] WINDOW_LINES = {
            "Te veo desde aquí...", "Déjame entrar.", "No cierres las cortinas...", "Abre la ventana."};
    private static final String[] DOOR_LINES = {
            "Mira detrás de la puerta...", "Ven... acércate.", "Ya casi te tengo."};
    private static final String[] BEHIND_LINES = {
            "Estoy detrás de ti...", "No voltees.", "Ya casi te alcanzo...", "Voltea... te estoy esperando."};
    private static final String[] STALK_LINES = {
            "No mires atrás.", "Sigo aquí...", "Corre."};

    private Mode mode = Mode.STALK;
    private UUID targetId;
    private int stage;
    private BlockPos doorPos;
    private BlockPos glassPos;

    private int lifeTicks;
    private int seenTicks;
    private int screamTicks;
    private boolean harmfulScream;
    private boolean hurtDone;
    private int pathTimer;
    private int heartbeatTimer;
    private int breathTimer = 60;
    private int whisperTimer = 200;
    private int lineTimer = 120;
    private int tapTicks;
    private int phase;
    private int phaseTicks;
    private int reachTicks;
    private boolean wasSeen;

    public StalkerEntity(EntityType<? extends StalkerEntity> type, World world) {
        super(type, world);
        this.experiencePoints = 0;
    }

    public static DefaultAttributeContainer.Builder createStalkerAttributes() {
        return MobEntity.createMobAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 40.0)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.26)
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 48.0)
                .add(EntityAttributes.GENERIC_KNOCKBACK_RESISTANCE, 1.0);
    }

    @Override
    protected void initDataTracker() {
        super.initDataTracker();
        this.dataTracker.startTracking(STATE, STATE_IDLE);
    }

    /** Lo llama el StalkerManager al crearlo. */
    public void bind(UUID playerId, int stage, Mode mode, BlockPos doorPos, BlockPos glassPos) {
        this.targetId = playerId;
        this.stage = stage;
        this.mode = mode;
        this.doorPos = doorPos;
        this.glassPos = glassPos;
    }

    public int getHorrorState() {
        return this.dataTracker.get(STATE);
    }

    private void setHorrorState(int s) {
        if (this.dataTracker.get(STATE) != s) {
            this.dataTracker.set(STATE, s);
        }
    }

    // ------------------------------------------------------------------
    // IA (solo servidor)
    // ------------------------------------------------------------------
    @Override
    protected void mobTick() {
        super.mobTick();
        lifeTicks++;

        ServerPlayerEntity player = findTarget();
        if (player == null) {
            this.discard();
            return;
        }

        double dist = this.distanceTo(player);
        if (dist > StalkerConfig.MAX_DISTANCE) {
            vanish(StalkerManager.Reason.QUIET, true);
            return;
        }
        if (lifeTicks > maxLife()) {
            vanish(mode == Mode.STALK ? StalkerManager.Reason.STARED_AT : StalkerManager.Reason.DONE, false);
            return;
        }

        tickAmbience(player, dist);

        if (screamTicks > 0) {
            tickScream(player);
            return;
        }

        switch (mode) {
            case WINDOW -> tickWindow(player, dist);
            case DOOR -> tickDoor(player, dist);
            case BEHIND -> tickBehind(player, dist);
            default -> tickStalk(player, dist);
        }
    }

    private int maxLife() {
        return switch (mode) {
            case WINDOW -> StalkerConfig.LIFE_WINDOW;
            case DOOR -> StalkerConfig.LIFE_DOOR;
            case BEHIND -> StalkerConfig.LIFE_BEHIND;
            default -> StalkerConfig.LIFE_STALK;
        };
    }

    private ServerPlayerEntity findTarget() {
        if (!(this.getWorld() instanceof ServerWorld serverWorld)) return null;
        if (targetId != null) {
            PlayerEntity candidate = serverWorld.getPlayerByUuid(targetId);
            if (candidate instanceof ServerPlayerEntity sp && sp.isAlive() && !sp.isSpectator()) {
                return sp;
            }
            return null;
        }
        // Creado con /summon o cargado del mundo: se une al jugador mas cercano.
        PlayerEntity nearest = serverWorld.getClosestPlayer(this, 64.0);
        if (nearest instanceof ServerPlayerEntity sp && !sp.isSpectator()) {
            targetId = sp.getUuid();
            return sp;
        }
        return null;
    }

    /** true si el jugador tiene al Acosador (casi) en el centro de la vista y sin bloques de por medio. */
    private boolean isLookedAtBy(PlayerEntity player, double dotNear, double dotFar) {
        Vec3d look = player.getRotationVec(1.0f).normalize();
        Vec3d toMe = this.getBoundingBox().getCenter().subtract(player.getEyePos());
        double len = toMe.length();
        if (len < 1.0E-4) return true;
        double dot = look.dotProduct(toMe.multiply(1.0 / len));
        double threshold = len < 10.0 ? dotNear : dotFar;
        return dot > threshold && player.canSee(this);
    }

    private void hold(ServerPlayerEntity player) {
        this.getNavigation().stop();
        faceEntity(player);
    }

    // ------------------------------------------------------------------
    // Modo ACECHAR
    // ------------------------------------------------------------------
    private void tickStalk(ServerPlayerEntity player, double dist) {
        boolean seen = isLookedAtBy(player, StalkerConfig.LOOK_DOT_NEAR, StalkerConfig.LOOK_DOT_FAR);
        setHorrorState(seen ? STATE_SEEN : STATE_IDLE);
        this.getLookControl().lookAt(player, 30.0f, 30.0f);

        if (dist < StalkerConfig.JUMPSCARE_DISTANCE) {
            startScream(player, true, true);
            return;
        }

        if (seen) {
            this.getNavigation().stop();
            seenTicks++;
            if (!wasSeen && dist > 10.0) {
                playWhisperNear(player);
            }
            if (dist > 8.0) {
                if (seenTicks >= stareLimit()) {
                    vanish(StalkerManager.Reason.STARED_AT, false);
                    return;
                }
            } else if (seenTicks >= StalkerConfig.CLOSE_STARE_PATIENCE_TICKS) {
                startScream(player, true, true);
                return;
            }
        } else {
            seenTicks = Math.max(0, seenTicks - 1);
            creepToward(player, dist);
        }
        wasSeen = seen;
    }

    private int stareLimit() {
        return Math.max(StalkerConfig.MIN_STARE_LIMIT_TICKS,
                StalkerConfig.STARE_LIMIT_TICKS - stage * StalkerConfig.STARE_LIMIT_STEP);
    }

    private void creepToward(ServerPlayerEntity player, double dist) {
        double speed = StalkerConfig.CREEP_SPEED + stage * StalkerConfig.SPEED_PER_STAGE;
        if (dist < 14.0) speed *= StalkerConfig.CLOSE_SPEED_BONUS;
        if (--pathTimer <= 0) {
            pathTimer = 10;
            this.getNavigation().startMovingTo(player, speed);
        }
        if (this.getNavigation().isIdle()) {
            this.getMoveControl().moveTo(player.getX(), player.getY(), player.getZ(), speed);
        }
    }

    // ------------------------------------------------------------------
    // Modo VENTANA
    // ------------------------------------------------------------------
    private void tickWindow(ServerPlayerEntity player, double dist) {
        hold(player);
        boolean seen = isLookedAtBy(player, 0.9, 0.9);

        if (tapTicks > 0) {
            tapTicks--;
            setHorrorState(STATE_TAP);
            if (tapTicks % 16 == 8) {
                glassHit();
            }
            if (tapTicks == 0) {
                setHorrorState(STATE_IDLE);
            }
        } else {
            setHorrorState(seen ? STATE_SEEN : STATE_IDLE);
        }

        if (seen) {
            seenTicks++;
        } else {
            seenTicks = Math.max(0, seenTicks - 1);
        }

        // Si estas cerca y no lo miras, pega las manos al vidrio y golpea.
        if (tapTicks == 0 && !seen && dist < 7.0 && lifeTicks > 100 && this.random.nextInt(50) == 0) {
            tapTicks = 70;
        }
        // Si lo miras fijamente, grita pegado al vidrio.
        if (tapTicks == 0 && seenTicks > 120) {
            seenTicks = 0;
            startScream(player, false, false);
            return;
        }
        if (--lineTimer <= 0) {
            lineTimer = 300 + this.random.nextInt(300);
            say(player, pick(WINDOW_LINES));
        }
    }

    private void glassHit() {
        BlockPos at = glassPos != null ? glassPos : this.getBlockPos();
        this.getWorld().playSound(null, at, SoundEvents.BLOCK_GLASS_HIT, SoundCategory.HOSTILE, 1.4f, 0.7f);
    }

    // ------------------------------------------------------------------
    // Modo PUERTA
    // ------------------------------------------------------------------
    private void tickDoor(ServerPlayerEntity player, double dist) {
        phaseTicks++;
        switch (phase) {
            case 0 -> {
                // Detras de la puerta cerrada: toca la madera y luego la abre.
                hold(player);
                if (phaseTicks == 100) {
                    BlockPos at = doorPos != null ? doorPos : this.getBlockPos();
                    this.getWorld().playSound(null, at, SoundEvents.ENTITY_ZOMBIE_ATTACK_WOODEN_DOOR,
                            SoundCategory.HOSTILE, 1.2f, 0.6f);
                }
                if (phaseTicks >= 170) {
                    setDoor(true);
                    say(player, DOOR_LINES[0]);
                    phase = 1;
                    phaseTicks = 0;
                }
            }
            case 1 -> {
                // Puerta abierta: te mira desde el hueco.
                hold(player);
                boolean seen = isLookedAtBy(player, 0.85, 0.85);
                setHorrorState(seen ? STATE_SEEN : STATE_IDLE);
                if (seen) {
                    seenTicks++;
                } else {
                    seenTicks = Math.max(0, seenTicks - 1);
                }
                if (seenTicks > 220) {
                    setDoor(false);
                    vanish(StalkerManager.Reason.DONE, false);
                    return;
                }
                if (phaseTicks > 60 && dist < 9.0 && this.random.nextInt(30) == 0) {
                    say(player, DOOR_LINES[1]);
                    phase = 2;
                    phaseTicks = 0;
                    reachTicks = 55;
                } else if (phaseTicks > 400) {
                    setDoor(false);
                    vanish(StalkerManager.Reason.DONE, false);
                }
            }
            case 2 -> {
                // Mete la mano y se lanza hacia ti.
                reachTicks--;
                setHorrorState(STATE_REACH);
                faceEntity(player);
                this.getMoveControl().moveTo(player.getX(), player.getY(), player.getZ(), 1.25);
                if (dist <= StalkerConfig.REACH_GRAB_DISTANCE) {
                    grab(player);
                    return;
                }
                if (reachTicks <= 0) {
                    phase = 3;
                    phaseTicks = 0;
                    setHorrorState(STATE_IDLE);
                }
            }
            default -> {
                // Fallo: retrocede y cierra la puerta.
                hold(player);
                if (phaseTicks == 20) {
                    setDoor(false);
                    vanish(StalkerManager.Reason.DONE, false);
                }
            }
        }
    }

    private void setDoor(boolean open) {
        if (doorPos == null) return;
        World w = this.getWorld();
        BlockState s = w.getBlockState(doorPos);
        if (s.getBlock() instanceof DoorBlock door && s.get(DoorBlock.OPEN) != open) {
            door.setOpen(this, w, s, doorPos, open);
        }
    }

    /** Te jala hacia el: tele-transporta al jugador pegado al Acosador y lo asusta con dano. */
    private void grab(ServerPlayerEntity player) {
        Vec3d dir = new Vec3d(player.getX() - this.getX(), 0.0, player.getZ() - this.getZ());
        if (dir.lengthSquared() > 1.0E-4) {
            dir = dir.normalize();
            player.requestTeleport(this.getX() + dir.x * 1.1, player.getY(), this.getZ() + dir.z * 1.1);
        }
        startScream(player, true, false);
    }

    // ------------------------------------------------------------------
    // Modo DETRAS
    // ------------------------------------------------------------------
    private void tickBehind(ServerPlayerEntity player, double dist) {
        hold(player);
        boolean seen = isLookedAtBy(player, 0.55, 0.55);

        if (lifeTicks == 20) {
            say(player, BEHIND_LINES[0]);
        }
        if (seen) {
            setHorrorState(STATE_SEEN);
            seenTicks++;
            // Te das la vuelta: lo ves un instante y grita.
            if (seenTicks >= 14) {
                startScream(player, false, true);
                return;
            }
        } else {
            setHorrorState(STATE_IDLE);
            seenTicks = 0;
        }

        if (lifeTicks == 260) {
            say(player, BEHIND_LINES[2]);
            stepCloser(player);
        }
        if (lifeTicks == 480) {
            say(player, BEHIND_LINES[1]);
            stepCloser(player);
        }
        // Si no volteas en todo ese tiempo, te ataca por la espalda.
        if (lifeTicks >= 680 && !seen) {
            startScream(player, true, true);
        }
    }

    private void stepCloser(ServerPlayerEntity player) {
        Vec3d dir = new Vec3d(player.getX() - this.getX(), 0.0, player.getZ() - this.getZ());
        if (dir.lengthSquared() < 4.0) return;
        dir = dir.normalize();
        double nx = this.getX() + dir.x * 0.9;
        double nz = this.getZ() + dir.z * 0.9;
        Box moved = this.getBoundingBox().offset(nx - this.getX(), 0.0, nz - this.getZ());
        if (this.getWorld().isSpaceEmpty(this, moved)) {
            this.refreshPositionAndAngles(nx, this.getY(), nz, this.getYaw(), 0.0f);
        }
    }

    // ------------------------------------------------------------------
    // Susto
    // ------------------------------------------------------------------
    /**
     * @param harmful si true, al final te hace dano
     * @param front   si true, aparece pegado a tu cara
     */
    private void startScream(ServerPlayerEntity player, boolean harmful, boolean front) {
        screamTicks = StalkerConfig.SCREAM_TICKS;
        harmfulScream = harmful;
        hurtDone = false;
        setHorrorState(STATE_SCREAM);
        this.getNavigation().stop();

        if (front) {
            Vec3d look = player.getRotationVec(1.0f);
            Vec3d flat = new Vec3d(look.x, 0.0, look.z);
            if (flat.lengthSquared() > 1.0E-4) {
                flat = flat.normalize();
                double tx = player.getX() + flat.x * 1.5;
                double tz = player.getZ() + flat.z * 1.5;
                Box moved = this.getBoundingBox().offset(tx - this.getX(), player.getY() - this.getY(), tz - this.getZ());
                if (this.getWorld().isSpaceEmpty(this, moved)) {
                    this.refreshPositionAndAngles(tx, player.getY(), tz, this.getYaw(), 0.0f);
                }
            }
        }
        faceEntity(player);

        this.getWorld().playSound(null, this.getX(), this.getY(), this.getZ(),
                ModSounds.SCREAM, SoundCategory.HOSTILE, 3.0f, 0.95f + this.random.nextFloat() * 0.1f);
        if (!harmful) {
            // Susto "limpio": solo oscuridad un instante (sin sacudir la camara, que marea en VR).
            player.addStatusEffect(new StatusEffectInstance(StatusEffects.DARKNESS, 60, 0, false, false, false));
        }
    }

    private void tickScream(ServerPlayerEntity player) {
        screamTicks--;
        this.getNavigation().stop();
        faceEntity(player);
        if (harmfulScream && !hurtDone && screamTicks <= StalkerConfig.SCREAM_TICKS - 12) {
            hurtDone = true;
            hurtPlayer(player);
        }
        if (screamTicks <= 0) {
            vanish(harmfulScream ? StalkerManager.Reason.ATTACKED : StalkerManager.Reason.DONE, true);
        }
    }

    private void faceEntity(ServerPlayerEntity player) {
        float yaw = (float) (MathHelper.atan2(player.getZ() - this.getZ(), player.getX() - this.getX()) * 180.0 / Math.PI) - 90.0f;
        this.setYaw(yaw);
        this.setHeadYaw(yaw);
        this.setBodyYaw(yaw);
    }

    private void hurtPlayer(ServerPlayerEntity player) {
        player.damage(this.getDamageSources().mobAttack(this), StalkerConfig.ATTACK_DAMAGE);
        player.addStatusEffect(new StatusEffectInstance(StatusEffects.DARKNESS, 100, 0, false, false, false));
        player.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 40, 1, false, false, false));
    }

    // ------------------------------------------------------------------
    // Voz y sonido
    // ------------------------------------------------------------------
    private String pick(String[] lines) {
        return lines[this.random.nextInt(lines.length)];
    }

    /** Frase en la barra de arriba (se lee bien en VR) + un susurro junto a tu oreja. */
    private void say(ServerPlayerEntity player, String line) {
        player.sendMessage(Text.literal("El Acosador: ").formatted(Formatting.DARK_RED)
                .append(Text.literal(line).formatted(Formatting.RED, Formatting.ITALIC)), true);
        playWhisperNear(player);
    }

    private void tickAmbience(ServerPlayerEntity player, double dist) {
        World world = this.getWorld();

        if (dist < 32.0 && --heartbeatTimer <= 0) {
            heartbeatTimer = (int) MathHelper.clamp(dist * 1.2, 12.0, 50.0);
            float volume = (float) MathHelper.clamp(1.6 - dist / 24.0, 0.25, 1.6);
            world.playSound(null, player.getX(), player.getY(), player.getZ(),
                    SoundEvents.ENTITY_WARDEN_HEARTBEAT, SoundCategory.AMBIENT, volume, 1.0f);
        }

        if (--breathTimer <= 0) {
            breathTimer = 80 + this.random.nextInt(80);
            world.playSound(null, this.getX(), this.getEyeY(), this.getZ(),
                    ModSounds.BREATH, SoundCategory.HOSTILE, 1.5f, 0.9f + this.random.nextFloat() * 0.2f);
        }

        if (dist < 40.0 && --whisperTimer <= 0) {
            whisperTimer = 240 + this.random.nextInt(260);
            if (mode == Mode.STALK && this.random.nextInt(3) == 0) {
                say(player, pick(STALK_LINES));
            } else {
                playWhisperNear(player);
            }
        }

        if (StalkerConfig.DARKNESS_PULSE && mode == Mode.STALK && stage >= 2 && dist < 24.0 && lifeTicks % 40 == 0) {
            player.addStatusEffect(new StatusEffectInstance(StatusEffects.DARKNESS, 80, 0, false, false, false));
        }
    }

    private void playWhisperNear(ServerPlayerEntity player) {
        double angle = this.random.nextDouble() * Math.PI * 2.0;
        this.getWorld().playSound(null,
                player.getX() + Math.cos(angle) * 3.5, player.getEyeY(), player.getZ() + Math.sin(angle) * 3.5,
                ModSounds.WHISPER, SoundCategory.HOSTILE, 1.4f, 0.85f + this.random.nextFloat() * 0.3f);
    }

    // ------------------------------------------------------------------
    // Desaparecer
    // ------------------------------------------------------------------
    private void vanish(StalkerManager.Reason reason, boolean silent) {
        if (this.getWorld() instanceof ServerWorld serverWorld) {
            serverWorld.spawnParticles(ParticleTypes.LARGE_SMOKE,
                    this.getX(), this.getY() + 1.4, this.getZ(), 25, 0.3, 0.9, 0.3, 0.02);
            if (!silent) {
                serverWorld.playSound(null, this.getX(), this.getY(), this.getZ(),
                        ModSounds.WHISPER, SoundCategory.HOSTILE, 1.6f, 0.8f);
            }
        }
        StalkerManager.notifyGone(targetId, reason);
        this.discard();
    }

    // ------------------------------------------------------------------
    // Ajustes de la entidad
    // ------------------------------------------------------------------
    @Override
    public boolean damage(DamageSource source, float amount) {
        if (source.isOf(DamageTypes.OUT_OF_WORLD) || source.isOf(DamageTypes.GENERIC_KILL)) {
            return super.damage(source, amount);
        }
        // Si lo golpeas, huye asustado.
        if (!this.getWorld().isClient && screamTicks <= 0 && source.getAttacker() instanceof ServerPlayerEntity) {
            setDoor(false);
            vanish(StalkerManager.Reason.SCARED, false);
        }
        return false;
    }

    @Override
    public boolean canHaveStatusEffect(StatusEffectInstance effect) {
        return false;
    }

    @Override
    protected float getActiveEyeHeight(EntityPose pose, EntityDimensions dimensions) {
        return 2.6f;
    }

    @Override
    protected void playStepSound(BlockPos pos, BlockState state) {
        this.playSound(SoundEvents.BLOCK_BONE_BLOCK_STEP, 0.55f, 0.5f);
    }
}
