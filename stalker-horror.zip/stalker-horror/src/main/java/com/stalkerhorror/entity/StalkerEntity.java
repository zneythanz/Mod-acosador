package com.stalkerhorror.entity;

import com.stalkerhorror.ModSounds;
import com.stalkerhorror.StalkerConfig;
import com.stalkerhorror.StalkerManager;
import net.minecraft.block.BlockState;
import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.EntityPose;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.damage.DamageTypes;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.mob.PathAwareEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

import java.util.UUID;

/**
 * El Acosador.
 *
 * - Te observa desde lejos y se queda quieto mientras lo miras.
 * - Si apartas la vista, se acerca.
 * - Si lo miras demasiado tiempo, desaparece... y vuelve mas cerca.
 * - Si llega hasta ti, te da un susto.
 *
 * Toda la IA corre en el servidor (mobTick); el cliente solo recibe 2 banderas
 * (esta siendo mirado / esta gritando) para animar el modelo. Es muy ligero.
 */
public class StalkerEntity extends PathAwareEntity {
    private static final TrackedData<Boolean> STARED_AT =
            DataTracker.registerData(StalkerEntity.class, TrackedDataHandlerRegistry.BOOLEAN);
    private static final TrackedData<Boolean> SCREAMING =
            DataTracker.registerData(StalkerEntity.class, TrackedDataHandlerRegistry.BOOLEAN);

    private UUID targetId;
    private int stage;
    private int lifeTicks;
    private int seenTicks;
    private int screamTicks;
    private int pathTimer;
    private int heartbeatTimer;
    private int breathTimer = 60;
    private int whisperTimer = 200;
    private boolean wasSeen;

    public StalkerEntity(EntityType<? extends StalkerEntity> type, World world) {
        super(type, world);
        this.experiencePoints = 0;
    }

    public static DefaultAttributeContainer.Builder createStalkerAttributes() {
        return MobEntity.createMobAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 40.0)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.26)
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 48.0)
                .add(EntityAttributes.GENERIC_KNOCKBACK_RESISTANCE, 1.0);
    }

    @Override
    protected void initDataTracker() {
        super.initDataTracker();
        this.dataTracker.startTracking(STARED_AT, false);
        this.dataTracker.startTracking(SCREAMING, false);
    }

    /** Lo llama el StalkerManager al crearlo. */
    public void bindTarget(UUID playerId, int stage) {
        this.targetId = playerId;
        this.stage = stage;
    }

    public boolean isStaredAt() {
        return this.dataTracker.get(STARED_AT);
    }

    public boolean isScreaming() {
        return this.dataTracker.get(SCREAMING);
    }

    // ------------------------------------------------------------------
    // IA (solo servidor)
    // ------------------------------------------------------------------
    @Override
    protected void mobTick() {
        super.mobTick();
        lifeTicks++;

        ServerPlayerEntity player = findTarget();
        if (player == null) {
            // Se recargo el mundo o el jugador murio/se fue: no deja rastro.
            this.discard();
            return;
        }

        double dist = this.distanceTo(player);

        if (dist > StalkerConfig.MAX_DISTANCE) {
            vanish(StalkerManager.Reason.QUIET, true);
            return;
        }
        if (lifeTicks > StalkerConfig.MAX_LIFETIME_TICKS) {
            vanish(StalkerManager.Reason.STARED_AT, false);
            return;
        }

        tickAmbience(player, dist);

        // --- Susto en curso ---
        if (screamTicks > 0) {
            screamTicks--;
            this.getNavigation().stop();
            faceEntity(player);
            if (screamTicks == StalkerConfig.SCREAM_TICKS - 12) {
                hurtPlayer(player);
            }
            if (screamTicks == 0) {
                vanish(StalkerManager.Reason.ATTACKED, true);
            }
            return;
        }

        boolean seen = isLookedAtBy(player);
        if (seen != isStaredAt()) {
            this.dataTracker.set(STARED_AT, seen);
        }
        this.getLookControl().lookAt(player, 30.0f, 30.0f);

        if (dist < StalkerConfig.JUMPSCARE_DISTANCE) {
            startJumpscare(player);
            return;
        }

        if (seen) {
            this.getNavigation().stop();
            seenTicks++;

            if (!wasSeen && dist > 10.0) {
                // Primer contacto visual: un susurro justo al lado de tu oreja.
                playWhisperNear(player);
            }

            if (dist > 8.0) {
                if (seenTicks >= stareLimit()) {
                    vanish(StalkerManager.Reason.STARED_AT, false);
                    return;
                }
            } else if (seenTicks >= StalkerConfig.CLOSE_STARE_PATIENCE_TICKS) {
                startJumpscare(player);
                return;
            }
        } else {
            seenTicks = Math.max(0, seenTicks - 1);
            creepToward(player, dist);
        }
        wasSeen = seen;
    }

    private int stareLimit() {
        return Math.max(StalkerConfig.MIN_STARE_LIMIT_TICKS,
                StalkerConfig.STARE_LIMIT_TICKS - stage * StalkerConfig.STARE_LIMIT_STEP);
    }

    private ServerPlayerEntity findTarget() {
        if (targetId == null || !(this.getWorld() instanceof ServerWorld serverWorld)) return null;
        PlayerEntity candidate = serverWorld.getPlayerByUuid(targetId);
        if (candidate instanceof ServerPlayerEntity sp && sp.isAlive() && !sp.isSpectator()) {
            return sp;
        }
        return null;
    }

    /** true si el jugador tiene al Acosador (casi) en el centro de la vista y sin bloques de por medio. */
    private boolean isLookedAtBy(PlayerEntity player) {
        Vec3d look = player.getRotationVec(1.0f).normalize();
        Vec3d toMe = this.getBoundingBox().getCenter().subtract(player.getEyePos());
        double len = toMe.length();
        if (len < 1.0E-4) return true;
        double dot = look.dotProduct(toMe.multiply(1.0 / len));
        double threshold = len < 10.0 ? StalkerConfig.LOOK_DOT_NEAR : StalkerConfig.LOOK_DOT_FAR;
        return dot > threshold && player.canSee(this);
    }

    private void creepToward(ServerPlayerEntity player, double dist) {
        double speed = StalkerConfig.CREEP_SPEED + stage * StalkerConfig.SPEED_PER_STAGE;
        if (dist < 14.0) speed *= StalkerConfig.CLOSE_SPEED_BONUS;

        // Recalcular la ruta solo cada medio segundo (ahorra CPU).
        if (--pathTimer <= 0) {
            pathTimer = 10;
            this.getNavigation().startMovingTo(player, speed);
        }
        if (this.getNavigation().isIdle()) {
            this.getMoveControl().moveTo(player.getX(), player.getY(), player.getZ(), speed);
        }
    }

    // ------------------------------------------------------------------
    // Susto
    // ------------------------------------------------------------------
    private void startJumpscare(ServerPlayerEntity player) {
        screamTicks = StalkerConfig.SCREAM_TICKS;
        this.dataTracker.set(SCREAMING, true);
        this.dataTracker.set(STARED_AT, false);
        this.getNavigation().stop();

        // Aparece pegado a tu cara, justo delante de donde miras.
        Vec3d look = player.getRotationVec(1.0f);
        Vec3d flat = new Vec3d(look.x, 0.0, look.z);
        if (flat.lengthSquared() > 1.0E-4) {
            flat = flat.normalize();
            double tx = player.getX() + flat.x * 1.5;
            double tz = player.getZ() + flat.z * 1.5;
            Box moved = this.getBoundingBox().offset(tx - this.getX(), player.getY() - this.getY(), tz - this.getZ());
            if (this.getWorld().isSpaceEmpty(this, moved)) {
                this.refreshPositionAndAngles(tx, player.getY(), tz, this.getYaw(), 0.0f);
            }
        }
        faceEntity(player);

        this.getWorld().playSound(null, this.getX(), this.getY(), this.getZ(),
                ModSounds.SCREAM, SoundCategory.HOSTILE, 3.0f, 1.0f);
    }

    private void faceEntity(ServerPlayerEntity player) {
        float yaw = (float) (MathHelper.atan2(player.getZ() - this.getZ(), player.getX() - this.getX()) * 180.0 / Math.PI) - 90.0f;
        this.setYaw(yaw);
        this.setHeadYaw(yaw);
        this.setBodyYaw(yaw);
    }

    private void hurtPlayer(ServerPlayerEntity player) {
        player.damage(this.getDamageSources().mobAttack(this), StalkerConfig.ATTACK_DAMAGE);
        player.addStatusEffect(new StatusEffectInstance(StatusEffects.DARKNESS, 100, 0, false, false, false));
        player.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 40, 1, false, false, false));
    }

    // ------------------------------------------------------------------
    // Sonido ambiente
    // ------------------------------------------------------------------
    private void tickAmbience(ServerPlayerEntity player, double dist) {
        World world = this.getWorld();

        // Latido: mas rapido y fuerte cuanto mas cerca.
        if (dist < 32.0 && --heartbeatTimer <= 0) {
            heartbeatTimer = (int) MathHelper.clamp(dist * 1.2, 12.0, 50.0);
            float volume = (float) MathHelper.clamp(1.6 - dist / 24.0, 0.25, 1.6);
            world.playSound(null, player.getX(), player.getY(), player.getZ(),
                    SoundEvents.ENTITY_WARDEN_HEARTBEAT, SoundCategory.AMBIENT, volume, 1.0f);
        }

        // Respiracion posicional: la oyes venir desde su direccion.
        if (--breathTimer <= 0) {
            breathTimer = 80 + this.random.nextInt(80);
            world.playSound(null, this.getX(), this.getEyeY(), this.getZ(),
                    ModSounds.BREATH, SoundCategory.HOSTILE, 1.5f, 0.9f + this.random.nextFloat() * 0.2f);
        }

        // Susurros cerca de tu oreja, en posiciones aleatorias.
        if (dist < 40.0 && --whisperTimer <= 0) {
            whisperTimer = 240 + this.random.nextInt(260);
            playWhisperNear(player);
        }

        // Pulsos de oscuridad en fases altas.
        if (StalkerConfig.DARKNESS_PULSE && stage >= 2 && dist < 24.0 && lifeTicks % 40 == 0) {
            player.addStatusEffect(new StatusEffectInstance(StatusEffects.DARKNESS, 80, 0, false, false, false));
        }
    }

    private void playWhisperNear(ServerPlayerEntity player) {
        double angle = this.random.nextDouble() * Math.PI * 2.0;
        this.getWorld().playSound(null,
                player.getX() + Math.cos(angle) * 3.5, player.getEyeY(), player.getZ() + Math.sin(angle) * 3.5,
                ModSounds.WHISPER, SoundCategory.HOSTILE, 1.4f, 0.85f + this.random.nextFloat() * 0.3f);
    }

    // ------------------------------------------------------------------
    // Desaparecer
    // ------------------------------------------------------------------
    private void vanish(StalkerManager.Reason reason, boolean silent) {
        if (this.getWorld() instanceof ServerWorld serverWorld) {
            serverWorld.spawnParticles(ParticleTypes.LARGE_SMOKE,
                    this.getX(), this.getY() + 1.4, this.getZ(), 25, 0.3, 0.9, 0.3, 0.02);
            if (!silent) {
                serverWorld.playSound(null, this.getX(), this.getY(), this.getZ(),
                        ModSounds.WHISPER, SoundCategory.HOSTILE, 1.6f, 0.8f);
            }
        }
        StalkerManager.notifyGone(targetId, reason);
        this.discard();
    }

    // ------------------------------------------------------------------
    // Ajustes de la entidad
    // ------------------------------------------------------------------
    @Override
    public boolean damage(DamageSource source, float amount) {
        // Solo /kill y el vacio lo eliminan. Si lo golpeas, huye asustado.
        if (source.isOf(DamageTypes.OUT_OF_WORLD) || source.isOf(DamageTypes.GENERIC_KILL)) {
            return super.damage(source, amount);
        }
        if (!this.getWorld().isClient && screamTicks <= 0 && source.getAttacker() instanceof ServerPlayerEntity) {
            vanish(StalkerManager.Reason.SCARED, false);
        }
        return false;
    }

    @Override
    public boolean canHaveStatusEffect(StatusEffectInstance effect) {
        return false;
    }

    @Override
    protected float getActiveEyeHeight(EntityPose pose, EntityDimensions dimensions) {
        return 2.6f;
    }

    @Override
    protected void playStepSound(BlockPos pos, BlockState state) {
        // Pasos secos, como huesos crujiendo.
        this.playSound(SoundEvents.BLOCK_BONE_BLOCK_STEP, 0.55f, 0.5f);
    }
}
